# WatchWin Demo

এটি WatchWin-এর একটি clickable demo prototype।
- Home
- Watch & Earn
- Wallet
- Withdraw
- Refer
- Profile

নোট: এটি বাস্তব টাকা দেয় না। আসল অ্যাপে backend, authentication, database, fraud prevention, approved rewarded-ad integration এবং বৈধ payment integration প্রয়োজন।
